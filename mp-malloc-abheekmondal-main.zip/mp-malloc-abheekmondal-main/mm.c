/******************************************************************************
 * 
 * Malloc lab header
 * 
 * Author: Abheek Mondal
 * Email:  amondal1@hawk.iit.edu
 * AID:    A20438046
 * Date:   12/02/2021
 * 
 * By signing above, I pledge on my honor that I neither gave nor received any
 * unauthorized assistance on the code contained in this repository.
 * 
 *****************************************************************************/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <unistd.h>
#include <stdbool.h>
#include "mm.h"
#include "memlib.h"

#define ALIGNMENT 8
#define ALIGN(size) (((size) + (ALIGNMENT-1)) & ~0x7)
#define SIZE_T_SIZE (ALIGN(sizeof(size_t)))

#define HDR_FROM_PL(ptr) ((void *)(ptr)-SIZE_T_SIZE)
#define PL_FROM_HDR(ptr) ((void *)(ptr) + SIZE_T_SIZE)

#define MIN_BLK_SIZE (4 * SIZE_T_SIZE)
#define NEXT_BLOCK(hdr) ((void *)(header) + GET_SIZE((header)))
#define PREV_BLOCK(hdr) (HEADER_OF(FOOTER_BEFORE(hdr)))


#define SET_UNUSED(hdr) (*(hdr) &= ~1)
#define SET_USED(hdr) (*(hdr) |= 1)
#define IS_USED(hdr) ((*(hdr)&1) == 1) 
#define IS_UNUSED(hdr) ((*(hdr)&1) == 0)

#define SET_SIZE(hdr, size) (*(hdr) = ((size) & -1) | IS_USED((hdr)))
#define GET_SIZE(hdr) (*(size_t *)(hdr) & ~1)

#define FOOTER_BEFORE(hdr) ((void *)(hdr)-SIZE_T_SIZE)
#define FOOTER_OF(hdr) FOOTER_BEFORE(NEXT_BLOCK(hdr))
#define HEADER_OF(ftr) ((void *)(ftr)-GET_SIZE(ftr) + SIZE_T_SIZE)

typedef struct flh {
	size_t size;
	struct flh *prev;
	struct flh *next;
}fl_hdr;


static bool in_heap(void *ptr) {
  return ptr >= mem_heap_lo() && ptr <= mem_heap_hi();
}



static inline void update_footer(size_t *header) {
  *(size_t *)(FOOTER_OF(header)) = *header;
}

static inline void remove_from_free_list(fl_hdr *block) {
   block->prev->next = block->next;
   block->next->prev = block->prev;
}

static inline void add_to_free_list(fl_hdr *block){
	fl_hdr *sentinel = mem_heap_lo();
	block->next = sentinel->next;
	block->prev = sentinel;
	sentinel->next->prev = block;
	sentinel->next = block;
}

static void use_block(fl_hdr *block, size_t blk_size){
   //SET_SIZE(header, blk_size);
   size_t *header = &block->size;
 //  block->prev->next = block->next;
 //  block->next->prev = block->prev;

 //remove_from_free_list(block);


  size_t next_size = GET_SIZE(header) - blk_size;
   if (next_size >= MIN_BLK_SIZE){
      SET_SIZE(header, blk_size);

   fl_hdr *next_block = (void *)header + blk_size;
   size_t *next_header = &next_block->size;
   SET_SIZE(next_header, next_size);
   SET_UNUSED(next_header);
   update_footer(next_header);  

   add_to_free_list(next_block);
   }

   SET_USED(header);
   update_footer(header);
}


static size_t *coalesce(size_t *header){
   size_t *final_header = header;

   size_t *next_header = NEXT_BLOCK(header);
   if (in_heap(next_header) && IS_UNUSED(next_header)) {
      remove_from_free_list((fl_hdr *)next_header);
      SET_SIZE(header, GET_SIZE(header) + GET_SIZE(next_header));
        
  }
   size_t *prev_header = PREV_BLOCK(header);
   if (in_heap(prev_header) && IS_UNUSED(prev_header)){
      remove_from_free_list((fl_hdr *)header);
      SET_SIZE(prev_header, GET_SIZE(prev_header) + GET_SIZE(header));
      final_header = prev_header;
   }

   return final_header;
}




int mm_init(void)
{
  fl_hdr *sentinel = mem_sbrk(MIN_BLK_SIZE);
  SET_SIZE(&sentinel->size, MIN_BLK_SIZE);
  SET_USED(&sentinel->size);
  sentinel->prev = sentinel;
  sentinel->next = sentinel;
  update_footer(&sentinel->size);
  return 0;
}

void *mm_malloc(size_t size){
  if (size == 448){
     size = 512;
  } else if (size == 112) {
    size = 128;
  }

  size_t blk_size = ALIGN(SIZE_T_SIZE + size + SIZE_T_SIZE);
  if (blk_size < MIN_BLK_SIZE) {
    blk_size = MIN_BLK_SIZE;
  }
   
  fl_hdr *sentinel = mem_heap_lo();
  fl_hdr *block = sentinel->next;
  while (block != sentinel) {
     if (GET_SIZE(&block->size) >= blk_size){
	remove_from_free_list(block);
	use_block(block, blk_size);
	return PL_FROM_HDR(&block->size);
     }
     block = block->next;
  }

/*
  size_t *header = mem_heap_lo();
  while (in_heap(header)) {
      if (IS_UNUSED(header) && GET_SIZE(header) >= blk_size) {
         use_block(header, blk_size);
         return PL_FROM_HDR(header);
      }  
      header = NEXT_BLOCK(header); 
  }
*/
// no suitable free blocks then expand the heap to get a new onw
  size_t *header = mem_sbrk(blk_size);
  if (header == (void *)-1) {
    return NULL;
  } else {
     SET_SIZE(header, blk_size);
     SET_USED(header);
     update_footer(header); 
   //*header = blk_size | 1;
    return PL_FROM_HDR(header);
  //  return (char *)header + SIZE_T_SIZE;
  }
}

void mm_free(void *ptr)
{
  size_t *header = HDR_FROM_PL(ptr);
  add_to_free_list((fl_hdr *)header);
  
  size_t *final_header = coalesce(header);
  //size_t *final_header = coalesce(header);
  SET_UNUSED(final_header);
  update_footer(final_header);

 // update_footer(header);
 // *header &= ~1L;

  // 00000001 -> 10000000
}

void *mm_realloc(void *ptr, size_t size){
  /* void *oldptr = ptr;
  void *newptr;
  size_t copySize;
    
  newptr = mm_malloc(size);
  if (newptr == NULL)
    return NULL;
  copySize = *(size_t *)((char *)oldptr - SIZE_T_SIZE);
  if (size < copySize)
    copySize = size;
  memcpy(newptr, oldptr, copySize);
  mm_free(oldptr);
  return newptr;
*/

	size_t *header = HDR_FROM_PL(ptr);
	size_t cur_size = GET_SIZE(header);
 	size_t new_size = ALIGN(SIZE_T_SIZE + size + SIZE_T_SIZE);

	if(new_size < MIN_BLK_SIZE) {
		new_size = MIN_BLK_SIZE;
	}
	if (cur_size >= new_size){
		return ptr;
	}
	size_t *next_header = NEXT_BLOCK(header);
	if (in_heap(next_header)) {
		size_t avail_size = GET_SIZE(header) + GET_SIZE(next_header);
		if (IS_UNUSED(next_header) && avail_size >= new_size) {
			remove_from_free_list((fl_hdr *)next_header);
			SET_SIZE(header, avail_size);
			update_footer(header);
			use_block((fl_hdr *)header, new_size);
			return ptr;
		}
	} else {
		size_t added_size = new_size - cur_size;
		if (mem_sbrk(added_size) == (void *)-1){
			return NULL;
		}
		SET_SIZE(header, new_size);
		update_footer(header);
		return ptr;      
	}
	void *new_allocation = mm_malloc(size);
	memcpy(new_allocation, ptr, cur_size - 2 * SIZE_T_SIZE);
	mm_free(ptr);
	return new_allocation;
}
