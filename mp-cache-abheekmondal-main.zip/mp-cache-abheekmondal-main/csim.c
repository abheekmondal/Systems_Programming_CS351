/******************************************************************************
 *
 * Cache lab header
 *
 * Author: Abheek Mondal
 * Email:  amondal1@hawk.iit.edu
 * AID:    A20438046
 * Date:   25/10/21
 *
 * By signing above, I pledge on my honor that I neither gave nor received any
 * unauthorized assistance on the code contained in this repository.
 *
 *****************************************************************************/
#include <stdio.h>
#include <getopt.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

#include "cachelab.h"

//typedef unsigned long long int uint; //bulletproof implementation of uint64_t

typedef struct {
	bool valid;
	uint64_t tag;
	uint64_t last_used;
} cache_line;

typedef struct{ //struct for cache which keeps accounting the important bits of informations
	uint64_t n_lines;
	cache_line *lines;

	uint64_t index_bits;
	uint64_t associativity;
	uint64_t block_bits;

	bool verbose;
	
	uint64_t clock;
	
	int hits;
	int misses;
	int evictions;
} cache_state;

//takes in an adress and returns index field
uint64_t get_index(cache_state *cache, uint64_t address){
	int tag_bits = 64 - (cache->index_bits + cache->block_bits);
	return (address << tag_bits) >> (tag_bits + cache->block_bits); //using bit shifts returns address, nothing to th left that we care about and shift that to the right 
}

uint64_t get_tag(cache_state *cache, uint64_t address){
	//int tag_bits = 64 - (cache->index_bits + cache->bloack_bits);
	return address >> (cache->index_bits + cache->block_bits); //chop off everything right to the tags
}

//uint64_t get_block_offset(cache_state *cache, uint64_t address){
//	int non_offset_bits = 64 - cache->block_bits;
//	return (address << non_offset_bits) >> non_offset_bits;
//}

//This is the main part that needs to be heavily modfied and is the brains for this code
void cache_access(cache_state *cache, uint64_t address, uint64_t size){
	//TODO	- the most intensive part of the program Needs to be heavily updated
	uint64_t index = get_index(cache, address);
	uint64_t tag = get_tag(cache, address);
	//uint64_t block_offset = get_block_offset(cache, address);

	int i = index * cache->associativity;
	cache_line *set = &cache->lines[i];
	cache_line *candidate = &set[0];

	for (int j = 0; j < cache->associativity; j++) {
		cache_line *line = &set[j];
		if (line->valid && line->tag == tag) { //check for hits, line is valid and tags match
			cache->hits++; //if fore is true increase hits by 1
			if (cache->verbose){
				printf("hit ");
			}
			//update lru
			line->last_used = cache->clock++;
			return;
		} else if (candidate->valid && !line->valid) {
			//serach for lru
			candidate = line;
		} else if (candidate->valid && line->valid && line->last_used < candidate->last_used) {
			candidate = line;
		} 
	}

	cache->misses++;
	if (cache->verbose) {
		printf("miss ");
	}

	if (candidate->valid) { //if missed and candidate is valid
		cache->evictions++;
		if (cache->verbose) {
			printf("eviction ");
		}
	}

	candidate->tag = tag;
	candidate->valid = true;	
	candidate->last_used = cache->clock++;
}


void cache_load(cache_state *cache, uint64_t address, uint64_t size){
	//TODO	- the most intensive part of the program Needs to be heavily updated	
	cache_access(cache, address, size);	
}

void cache_store(cache_state *cache, uint64_t address, uint64_t size){ //dependent on the load but because we just need to know the HME theres nothing much to it
	cache_access(cache, address, size);	

}

void cache_modify(cache_state *cache, uint64_t address, uint64_t size){// dependent on the load and store and because we just need the HME theres nothing much to it.
	//TODO	
	cache_load(cache, address, size);
	cache_store(cache, address, size);

}

int parse_int(char *s){
	int x;
	if (sscanf(s, "%d", &x) < 1){
		printf("Error: '%s' is not a valid number\n",  s);
		exit(-1);
	}
	return x;
}

int main(int argc, char *argv[]){
	bool help = false;
	bool verbose = false;
	uint64_t index_bits = 0;
	uint64_t associativity = 0;
	uint64_t block_bits = 0;
	char *tracefile = NULL;

	char c;
	while ((c = getopt(argc, argv, "hvs:E:b:t:"))!= -1){ //Parse the inputs
		//printf("opt: '%c'\n", c);
		switch (c){
			case 'h':
				help = true;
				break;
			case 'v':
				verbose = true;
				break;
			case 's':
				index_bits = parse_int(optarg); //log base 2 of the number of sets
				break;
			case 'E':
				associativity = parse_int(optarg); //number of lines per set
				break;
			case 'b':
				block_bits = parse_int(optarg);
				break;
			case 't':
				tracefile = strdup(optarg);
				break;
		}
	}
	if (help){ //check the inputs
		printf("Usage: ./csim-ref [-hv] -s <s> -E <E> -b <b> -t <tracefile>\n");
		return 0;
	}

	if (tracefile == NULL){ //Find the file
		printf("Please specify a trace file.\n");
		return -1;
	}
	FILE *trace = fopen(tracefile, "r"); //verify that you can read the file
	if (trace == NULL){
		printf("Invalid trace file.\n");
		return -1;
	}
	 
	//Allocate the cache
// cache space needed = (s^2) * E
	uint64_t n_lines = associativity * (1 << index_bits);
	cache_line *lines = malloc(n_lines * sizeof(cache_line)); //array for cache lines
	for (uint64_t i = 0; i < n_lines; i++){
		lines[i].valid = false;
		lines[i].last_used = 0;
		lines[i].tag = 0;
	}

	//declare a cache state "object"
	cache_state cache = {
	// and initialize it	
		n_lines,
		lines,
		index_bits,
		associativity,
		block_bits,
		verbose,
		0,
		0, 0, 0,
	};

	#define LINELEN 64 //Overkill but can be lowered

	//Actually read the file
	char input_line[LINELEN];
	while (fgets(input_line, LINELEN, trace) != NULL){
		if (input_line[0] != ' '){
			continue;
		}

		char operation;
		uint64_t address;
		uint64_t size;

		int n = sscanf(input_line, " %c %lx,%ld", &operation, &address, &size);
		if (n < 3) {
			printf("syntax error: %s", input_line);
			return -1;
		}
		
		switch (operation){
			case 'L':
				cache_load(&cache, address, size);
				break;
			case 'S':
				cache_store(&cache, address, size);
				break;
			case 'M':
				//printf("modify\n");
				cache_modify(&cache, address, size);
				break;
		}
		if (cache.verbose) { //if verbose was enabled, add a new lne
			printf("\n");
		}		
		
	}


	printSummary(cache.hits, cache.misses, cache.evictions);
	//block_bits ^= block_bits;
	//verbose ^= verbose;	
	
//	free(tracefile);
	return 0;
}
